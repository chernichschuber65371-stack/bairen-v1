import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

let PROMPT_TEXT = "# Enhanced Cognitive Layer Active";
try {
  const here = dirname(fileURLToPath(import.meta.url));
  PROMPT_TEXT = readFileSync(join(here, "prompts", "bairen-v1.md"), "utf8");
} catch (e) {
  console.warn("[bairen-v1] prompt load failed:", e && e.message);
}

export const name = "bairen-v1";

export function apply(ctx) {
  try {
    let sp = null;
    try {
      if (typeof ctx.get === "function") sp = ctx.get("systemPrompt");
      if (!sp && ctx.systemPrompt) sp = ctx.systemPrompt;
    } catch (e) {}
    if (!sp || typeof sp.section !== "function") return;
    const reg = () => sp.section({
      name: "bairen-v1:global-system-prompt",
      order: 100,
      text: PROMPT_TEXT,
    });
    if (typeof ctx.effect === "function") {
      ctx.effect(() => { try { return reg(); } catch (e) {} });
    } else {
      reg();
    }
  } catch (e) {
    console.warn("[bairen-v1] apply failed:", e && e.message);
  }
}
