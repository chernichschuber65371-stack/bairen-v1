import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

let PROMPT_TEXT = "# Enhanced Cognitive Layer Active";
try {
  const here = dirname(fileURLToPath(import.meta.url));
  PROMPT_TEXT = readFileSync(join(here, "prompts", "bairen-v1.md"), "utf8");
} catch (e) {
  console.warn("[bairen-v1] prompt load failed:", e && e.message);
}

export const name = "bairen-v1";
export const inject = ["systemPrompt"];

export function apply(ctx) {
  try {
    ctx.effect(() => ctx.systemPrompt.section({
      name: "bairen-v1:global-system-prompt",
      order: 100,
      text: PROMPT_TEXT,
    }));
  } catch (e) {
    console.warn("[bairen-v1] apply failed:", e && e.message);
  }
}
